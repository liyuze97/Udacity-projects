# AIPND_CN_P2_Explore_Movie_Dataset
nd089-cn-p2，针对Udacity CN AIPND P2项目

欢迎来到这里，你需要的一切尽在`Explore Movie Dataset.ipynb`

Enjoy coding!